create definer = root@localhost view verreservacliente as
select `proyectofinal`.`cliente`.`Nombre`           AS `Nombre`,
       `proyectofinal`.`cliente`.`Apellido`         AS `Apellido`,
       `proyectofinal`.`cliente`.`Cedula`           AS `Cedula_Del_Cliente`,
       `proyectofinal`.`carro`.`Marca`              AS `Marca`,
       `proyectofinal`.`carro`.`Modelo`             AS `Modelo`,
       `proyectofinal`.`carro`.`Anio`               AS `Anio`,
       `proyectofinal`.`reserva`.`FechaReservacion` AS `Fecha_Reservacion`,
       `proyectofinal`.`reserva`.`FechaDeEntrega`   AS `Fecha_De_Entrega`,
       `proyectofinal`.`reserva`.`FechaDevolucion`  AS `Fecha_De_Devolucion`
from ((`proyectofinal`.`cliente` join `proyectofinal`.`reserva` on ((`proyectofinal`.`cliente`.`IDCliente` =
                                                                     `proyectofinal`.`reserva`.`IDCliente`))) join `proyectofinal`.`carro`
      on ((`proyectofinal`.`carro`.`IDCarro` = `proyectofinal`.`reserva`.`IDCarro`)))
where (`proyectofinal`.`reserva`.`Cancelacion` = false);

