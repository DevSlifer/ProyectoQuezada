create definer = root@localhost view informacioncliente as
select `proyectofinal`.`cliente`.`Nombre`                AS `Nombre`,
       `proyectofinal`.`cliente`.`Apellido`              AS `apellido`,
       `proyectofinal`.`cliente`.`Cedula`                AS `Cedula`,
       `proyectofinal`.`cliente`.`telefono`              AS `telefono`,
       `proyectofinal`.`cliente`.`Licencia`              AS `licencia`,
       `proyectofinal`.`direccioncliente`.`Provincia`    AS `Provincia`,
       `proyectofinal`.`direccioncliente`.`Sector`       AS `Sector`,
       `proyectofinal`.`direccioncliente`.`Calle`        AS `Calle`,
       `proyectofinal`.`direccioncliente`.`NumeroDeCasa` AS `NumeroDeCasa`
from (`proyectofinal`.`cliente` join `proyectofinal`.`direccioncliente`
      on ((`proyectofinal`.`cliente`.`IDCliente` = `proyectofinal`.`direccioncliente`.`IDCliente`)))
group by `proyectofinal`.`cliente`.`IDCliente`;

