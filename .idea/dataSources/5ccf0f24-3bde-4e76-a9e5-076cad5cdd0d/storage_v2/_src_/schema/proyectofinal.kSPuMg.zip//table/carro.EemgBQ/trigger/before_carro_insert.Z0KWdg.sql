create definer = root@localhost trigger before_carro_insert
    before insert
    on carro
    for each row
BEGIN
    IF NEW.Anio <= 2000 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'El año del carro debe ser mayor a 2000';
    END IF;
END;

