create
    definer = root@localhost procedure sp_actualizar_empleado(IN p_Nombre varchar(20), IN p_Apellido varchar(20),
                                                              IN p_Salario decimal(10, 2), IN p_Cedula varchar(11),
                                                              IN p_telefono varchar(13))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
    BEGIN
        ROLLBACK;
        RESIGNAL;
    end;

    START TRANSACTION;

    IF EXISTS (SELECT 1 FROM Empleado WHERE Cedula = p_Cedula) THEN
        UPDATE Empleado
        SET Nombre = coalesce(p_Nombre, nombre),
            Apellido = coalesce(p_Apellido, apellido),
            Salario = coalesce(p_Salario,salario),
            telefono = coalesce(p_telefono, telefono)
        WHERE Cedula = p_Cedula;
    ELSE
        SELECT 'El empleado especificado no existe' AS MensajeError;
    END IF;
END;

