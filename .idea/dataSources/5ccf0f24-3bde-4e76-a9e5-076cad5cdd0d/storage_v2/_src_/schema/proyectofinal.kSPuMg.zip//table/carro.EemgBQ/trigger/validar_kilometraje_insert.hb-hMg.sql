create definer = root@localhost trigger validar_kilometraje_insert
    before insert
    on carro
    for each row
BEGIN
    IF NEW.Kilometraje < 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'El kilometraje no puede ser negativo';
    END IF;
END;

