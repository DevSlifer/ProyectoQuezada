create
    definer = root@localhost function fn_calcular_monto_por_cedula(p_Cedula varchar(20), p_FechaInicio date, p_FechaFin date) returns decimal(10, 2)
    deterministic
BEGIN
    DECLARE v_PrecioPorDia DECIMAL(10,2);
    DECLARE v_DiasTotal INT;
    DECLARE v_MontoTotal DECIMAL(10,2);
    
    SELECT C.PrecioPorDia 
    INTO v_PrecioPorDia
    FROM Reserva R
    JOIN Cliente CL ON R.IDCliente = CL.IDCliente
    JOIN Carro C ON R.IDCarro = C.IDCarro
    WHERE CL.Cedula = p_Cedula
    AND R.FechaDeEntrega = p_FechaInicio
    AND R.FechaDevolucion = p_FechaFin
    AND R.Cancelacion = FALSE;
    
    SET v_DiasTotal = DATEDIFF(p_FechaFin, p_FechaInicio) + 1;
    
    SET v_MontoTotal = v_DiasTotal * IFNULL(v_PrecioPorDia, 0);
    
    RETURN v_MontoTotal;
END;

