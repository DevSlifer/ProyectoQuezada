create
    definer = root@localhost procedure sp_borrar_cliente(IN p_Cedula varchar(11))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
    BEGIN
        ROLLBACK;
        RESIGNAL;
    end;

    START TRANSACTION;

    DELETE FROM cliente
    WHERE cedula = p_cedula;

    COMMIT;
end;

