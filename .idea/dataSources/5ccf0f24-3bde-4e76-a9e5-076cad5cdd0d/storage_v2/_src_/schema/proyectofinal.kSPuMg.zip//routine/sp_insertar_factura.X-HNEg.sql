create
    definer = root@localhost procedure sp_insertar_factura(IN p_Cedula varchar(20), IN p_FechaInicio date,
                                                           IN p_FechaFin date, IN p_CargosAdicionales int,
                                                           IN p_FechaDePago date)
BEGIN
    DECLARE v_Monto DECIMAL(10,2);
    DECLARE v_IDCliente INT;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    
    SELECT IDCliente INTO v_IDCliente
    FROM Cliente
    WHERE Cedula = p_Cedula;
    
    IF v_IDCliente IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Cliente no encontrado con la cédula proporcionada';
    END IF;
    
    SET v_Monto = fn_calcular_monto_por_cedula(p_Cedula, p_FechaInicio, p_FechaFin);
    
    IF v_Monto = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'No se encontró una reserva activa para este cliente en las fechas especificadas';
    END IF;
    
    START TRANSACTION;
    
    INSERT INTO Factura (
        Monto, 
        CargosAdicionales, 
        FechaDePago, 
        IDCliente
    )
    VALUES (
        v_Monto,
        p_CargosAdicionales,
        p_FechaDePago,
        v_IDCliente
    );
    
    COMMIT;
END;

