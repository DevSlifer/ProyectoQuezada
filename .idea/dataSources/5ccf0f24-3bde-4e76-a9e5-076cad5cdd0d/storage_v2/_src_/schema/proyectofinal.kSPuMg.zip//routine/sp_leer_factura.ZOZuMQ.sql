create
    definer = root@localhost procedure sp_leer_factura(IN p_cedula varchar(11))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
    BEGIN
        SELECT 'Ocurrió un error al intentar obtener las facturas' AS MensajeError;
        RESIGNAL;
    END;

    SELECT * 
    FROM facturasgeneradas
    WHERE (p_Cedula IS NULL OR Cedula = p_Cedula);
END;

