create definer = root@localhost trigger before_reserva_insert
    before insert
    on reserva
    for each row
BEGIN
    IF NEW.FechaDeEntrega > NEW.FechaDevolucion THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Fecha de entrega debe ser anterior a fecha de devolución';
    END IF;
END;

