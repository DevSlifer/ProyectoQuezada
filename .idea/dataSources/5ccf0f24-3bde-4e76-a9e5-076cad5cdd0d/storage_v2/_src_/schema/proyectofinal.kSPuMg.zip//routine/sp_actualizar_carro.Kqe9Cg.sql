create
    definer = root@localhost procedure sp_actualizar_carro(IN p_Marca varchar(20), IN p_Modelo varchar(20),
                                                           IN p_Anio int, IN p_Placa varchar(9),
                                                           IN p_Matricula varchar(50), IN p_preciopordia int,
                                                           IN p_kilometraje decimal(10, 2))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
    BEGIN
        ROLLBACK;
        RESIGNAL;
    end;

    START TRANSACTION;

    UPDATE Carro
    SET 
        Marca = COALESCE(p_Marca, Marca),
        Modelo = COALESCE(p_Modelo, Modelo), 
        Anio = COALESCE(p_Anio, Anio), 
        Placa = COALESCE(p_Placa, Placa),
        Preciopordia = coalesce (p_preciopordia, preciopordia),
        kilometraje = coalesce (p_kilometraje, preciopordia)
    WHERE Matricula = p_Matricula;

    COMMIT;
END;

