create definer = root@localhost trigger validar_licencia_cliente
    before insert
    on reserva
    for each row
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM Cliente 
        WHERE IDCliente = NEW.IDCliente 
        AND Licencia IS NOT NULL
    ) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'El cliente debe tener licencia registrada para realizar una reserva';
    END IF;
END;

