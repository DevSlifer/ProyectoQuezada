create
    definer = root@localhost procedure sp_actualizar_cliente(IN p_Cedula varchar(11), IN p_Nombre varchar(20),
                                                             IN p_Apellido varchar(20), IN p_Licencia varchar(13),
                                                             IN p_Provincia varchar(50), IN p_Sector varchar(50),
                                                             IN p_Calle varchar(100), IN p_NumeroDeCasa int,
                                                             IN p_Telefono varchar(15))
BEGIN
    DECLARE v_IDCliente INT;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    SELECT IDCliente INTO v_IDCliente 
    FROM Cliente 
    WHERE Cedula = p_Cedula;
    
    IF v_IDCliente IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Cliente no encontrado';
    END IF;

    START TRANSACTION;

    UPDATE Cliente
    SET 
        Nombre = COALESCE(p_Nombre, Nombre),
        Apellido = COALESCE(p_Apellido, Apellido),
        Licencia = COALESCE(p_Licencia, Licencia),
        Telefono = COALESCE(p_Telefono, Telefono)
    WHERE IDCliente = v_IDCliente;

    IF p_Provincia IS NOT NULL OR p_Sector IS NOT NULL OR p_Calle IS NOT NULL OR p_NumeroDeCasa IS NOT NULL THEN
        UPDATE DireccionCliente
        SET 
            Provincia = COALESCE(p_Provincia, Provincia),
            Sector = COALESCE(p_Sector, Sector),
            Calle = COALESCE(p_Calle, Calle),
            NumeroDeCasa = COALESCE(p_NumeroDeCasa, NumeroDeCasa)
        WHERE IDCliente = v_IDCliente;
    END IF;

    COMMIT;
END;

