create
    definer = root@localhost procedure sp_eliminar_reserva(IN p_Cedula varchar(11), IN p_Placa varchar(9))
BEGIN
    DECLARE v_IDCliente INT;
    DECLARE v_IDCarro INT;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN 
        ROLLBACK;
        RESIGNAL;
    END;
    
    IF p_Cedula IS NOT NULL THEN
        SELECT IDCliente INTO v_IDCliente 
        FROM Cliente 
        WHERE Cedula = p_Cedula;
        
        IF v_IDCliente IS NULL THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Cliente no encontrado';
        END IF;
    END IF;
    
    IF p_Placa IS NOT NULL THEN
        SELECT IDCarro INTO v_IDCarro 
        FROM Carro 
        WHERE Placa = p_Placa;
        
        IF v_IDCarro IS NULL THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Carro no encontrado';
        END IF;
    END IF;
    
    START TRANSACTION;
    
    UPDATE Reserva 
    SET Cancelacion = TRUE
    WHERE 
        (v_IDCliente IS NULL OR IDCliente = v_IDCliente)
        AND (v_IDCarro IS NULL OR IDCarro = v_IDCarro)
        AND Cancelacion = FALSE;
    
    IF ROW_COUNT() = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'No se encontraron reservas activas para cancelar';
    END IF;
    
    COMMIT;
END;

