create
    definer = root@localhost procedure sp_leer_reservas(IN p_Cedula varchar(11), IN p_Placa varchar(9))
BEGIN
    SELECT * FROM rentacliente
    WHERE 
        (p_Cedula IS NULL OR Cedula = p_Cedula)
        AND (p_Placa IS NULL OR Placa = p_Placa)
    ORDER BY FechaReservacion DESC;
END;

