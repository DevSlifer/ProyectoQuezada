create
    definer = root@localhost procedure sp_insertar_cliente(IN p_Nombre varchar(20), IN p_Apellido varchar(20),
                                                           IN p_Cedula varchar(11), IN p_Licencia varchar(13),
                                                           IN p_Provincia varchar(50), IN p_Sector varchar(50),
                                                           IN p_Calle varchar(100), IN p_NumeroDeCasa int,
                                                           IN p_Telefono varchar(15))
begin  
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    end;

    START TRANSACTION;
    
    insert into cliente(nombre, apellido, cedula,licencia, telefono) values 
    (p_nombre,p_apellido, p_cedula,p_licencia, p_telefono);
    SET @new_IDCliente = LAST_INSERT_ID();

	IF p_Provincia IS NOT NULL AND p_Sector IS NOT NULL THEN
        INSERT INTO DireccionCliente (Provincia, Sector, Calle, NumeroDeCasa, IDCliente)
        VALUES (p_Provincia, p_Sector, p_Calle, p_NumeroDeCasa, @new_IDCliente);
    END IF;
    COMMIT;
END;

