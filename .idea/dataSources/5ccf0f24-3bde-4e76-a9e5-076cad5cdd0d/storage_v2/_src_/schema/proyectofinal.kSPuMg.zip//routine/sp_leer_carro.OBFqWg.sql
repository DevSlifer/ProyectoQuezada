create
    definer = root@localhost procedure sp_leer_carro(IN p_matricula varchar(50))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
    BEGIN
        SELECT 'Ocurrió un error al intentar obtener los carros' AS MensajeError;
        RESIGNAL;
    END;

    SELECT * 
    FROM carro
    WHERE (p_matricula IS NULL OR matricula = p_matricula);
END;

