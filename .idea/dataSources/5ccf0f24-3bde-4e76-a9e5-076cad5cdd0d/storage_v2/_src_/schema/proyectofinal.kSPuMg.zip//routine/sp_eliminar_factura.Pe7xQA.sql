create
    definer = root@localhost procedure sp_eliminar_factura(IN p_Cedula varchar(20), OUT p_FacturasEliminadas int)
BEGIN
    DECLARE v_IDCliente INT;
    DECLARE v_existe_cliente INT;
    DECLARE v_existe_factura INT;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    
    SELECT COUNT(*), IDCliente 
    INTO v_existe_cliente, v_IDCliente
    FROM Cliente
    WHERE Cedula = p_Cedula;
    
    IF v_existe_cliente = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'No existe un cliente con la cédula especificada';
    END IF;
    
    SELECT COUNT(*) INTO v_existe_factura
    FROM Factura
    WHERE IDCliente = v_IDCliente;
    
    IF v_existe_factura = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'No existen facturas para el cliente especificado';
    END IF;
    
    START TRANSACTION;
    
    SET p_FacturasEliminadas = (
        SELECT COUNT(*) 
        FROM Factura 
        WHERE IDCliente = v_IDCliente
    );
    
    DELETE FROM Factura 
    WHERE IDCliente = v_IDCliente;
    
    COMMIT;
    
    SELECT 
        CL.Cedula,
        CL.Nombre,
        p_FacturasEliminadas as FacturasEliminadas
    FROM Cliente CL
    WHERE CL.IDCliente = v_IDCliente;
    
END;

