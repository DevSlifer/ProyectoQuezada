create
    definer = root@localhost procedure sp_actualizar_factura(IN p_Cedula varchar(20), IN p_NuevoMonto decimal(10, 2),
                                                             IN p_NuevosCargosAdicionales int, IN p_NuevaFechaPago date)
BEGIN
    DECLARE v_IDCliente INT;
    DECLARE v_existe_cliente INT;
    DECLARE v_existe_factura INT;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    
    SELECT COUNT(*), IDCliente 
    INTO v_existe_cliente, v_IDCliente
    FROM Cliente
    WHERE Cedula = p_Cedula;
    
    IF v_existe_cliente = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'No existe un cliente con la cédula especificada';
    END IF;
    
    SELECT COUNT(*) INTO v_existe_factura
    FROM Factura
    WHERE IDCliente = v_IDCliente;
    
    IF v_existe_factura = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'No existe factura para el cliente especificado';
    END IF;
    
    START TRANSACTION;
    
    -- Actualizar la factura
    UPDATE Factura
    SET 
        Monto = CASE 
            WHEN p_NuevoMonto IS NOT NULL THEN p_NuevoMonto 
            ELSE Monto 
        END,
        CargosAdicionales = CASE 
            WHEN p_NuevosCargosAdicionales IS NOT NULL THEN p_NuevosCargosAdicionales 
            ELSE CargosAdicionales 
        END,
        FechaDePago = CASE 
            WHEN p_NuevaFechaPago IS NOT NULL THEN p_NuevaFechaPago 
            ELSE FechaDePago 
        END
    WHERE IDCliente = v_IDCliente;
    
    COMMIT;
    
    -- Mostrar la factura actualizada
    SELECT 
        F.*,
        C.Cedula,
        C.Nombre
    FROM Factura F
    JOIN Cliente C ON F.IDCliente = C.IDCliente
    WHERE F.IDCliente = v_IDCliente;
    
END;

