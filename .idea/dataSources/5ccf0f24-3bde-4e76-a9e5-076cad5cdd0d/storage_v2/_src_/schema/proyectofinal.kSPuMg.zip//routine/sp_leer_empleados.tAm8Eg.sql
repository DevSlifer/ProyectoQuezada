create
    definer = root@localhost procedure sp_leer_empleados(IN p_Cedula varchar(11))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
    BEGIN
        SELECT 'Ocurrió un error al intentar obtener los empleados' AS MensajeError;
        RESIGNAL;
    END;

    SELECT * 
    FROM empleado
    WHERE (p_Cedula IS NULL OR Cedula = p_Cedula);
END;

