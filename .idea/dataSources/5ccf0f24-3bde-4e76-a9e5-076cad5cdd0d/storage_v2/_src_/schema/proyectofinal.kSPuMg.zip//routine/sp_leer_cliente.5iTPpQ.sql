create
    definer = root@localhost procedure sp_leer_cliente(IN p_Cedula varchar(11))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
    BEGIN
        SELECT 'Ocurrió un error al intentar obtener los clientes' AS MensajeError;
        RESIGNAL;
    END;

    SELECT * 
    FROM informacioncliente
    WHERE (p_Cedula IS NULL OR Cedula = p_Cedula);
END;

