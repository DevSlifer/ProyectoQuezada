create definer = root@localhost trigger before_reserva_licencia
    before insert
    on reserva
    for each row
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Cliente WHERE IDCliente = NEW.IDCliente AND Licencia IS NOT NULL) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Cliente debe tener licencia para realizar reserva';
    END IF;
END;

