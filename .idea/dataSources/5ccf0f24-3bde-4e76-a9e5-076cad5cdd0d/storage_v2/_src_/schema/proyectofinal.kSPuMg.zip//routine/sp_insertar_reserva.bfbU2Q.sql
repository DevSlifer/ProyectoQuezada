create
    definer = root@localhost procedure sp_insertar_reserva(IN p_Cedula varchar(11), IN p_Placa varchar(9),
                                                           IN p_FechaEntrega date, IN p_FechaDevolucion date)
BEGIN
    DECLARE v_IDCliente INT;
    DECLARE v_IDCarro INT;
    DECLARE v_CarroDisponible BOOLEAN;
    
    -- Manejador de errores
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN 
        ROLLBACK;
        RESIGNAL;
    END;
    
    -- Validar que el cliente existe y obtener su ID
    SELECT IDCliente INTO v_IDCliente 
    FROM Cliente 
    WHERE Cedula = p_Cedula;
    
    IF v_IDCliente IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Cliente no encontrado. Debe registrar el cliente primero.';
    END IF;
    
    -- Validar que el cliente tenga licencia
    IF NOT EXISTS (SELECT 1 FROM Cliente WHERE IDCliente = v_IDCliente AND Licencia IS NOT NULL) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'El cliente debe tener una licencia registrada para realizar una reserva.';
    END IF;
    
    -- Validar que el carro existe y obtener su ID
    SELECT IDCarro INTO v_IDCarro 
    FROM Carro 
    WHERE Placa = p_Placa;
    
    IF v_IDCarro IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Carro no encontrado. Verifique la placa ingresada.';
    END IF;
    
    -- Validar fechas
    IF p_FechaEntrega >= p_FechaDevolucion THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'La fecha de entrega debe ser anterior a la fecha de devolución.';
    END IF;
    
    IF p_FechaEntrega < CURDATE() THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'La fecha de entrega no puede ser anterior a la fecha actual.';
    END IF;
    
    -- Verificar disponibilidad del carro para las fechas solicitadas
    SELECT NOT EXISTS (
        SELECT 1 
        FROM Reserva 
        WHERE IDCarro = v_IDCarro 
        AND Cancelacion = FALSE
        AND (
            (p_FechaEntrega BETWEEN FechaDeEntrega AND FechaDevolucion) OR
            (p_FechaDevolucion BETWEEN FechaDeEntrega AND FechaDevolucion) OR
            (FechaDeEntrega BETWEEN p_FechaEntrega AND p_FechaDevolucion)
        )
    ) INTO v_CarroDisponible;
    
    IF NOT v_CarroDisponible THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'El carro no está disponible para las fechas seleccionadas.';
    END IF;
    
    START TRANSACTION;
    
    -- Insertar la reserva
    INSERT INTO Reserva(
        FechaReservacion, 
        FechaDeEntrega, 
        FechaDevolucion, 
        IDCliente, 
        IDCarro
    ) VALUES (
        CURDATE(),
        p_FechaEntrega,
        p_FechaDevolucion,
        v_IDCliente,
        v_IDCarro
    );
    
    COMMIT;
END;

