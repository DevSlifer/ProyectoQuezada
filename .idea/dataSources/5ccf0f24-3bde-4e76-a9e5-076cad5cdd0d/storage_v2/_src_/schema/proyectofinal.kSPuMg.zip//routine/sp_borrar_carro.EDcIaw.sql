create
    definer = root@localhost procedure sp_borrar_carro(IN p_matricula varchar(50))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
    BEGIN
        ROLLBACK;
        RESIGNAL;
    end;

    START TRANSACTION;

    DELETE FROM carro
    WHERE matricula = p_matricula;

    COMMIT;
end;

