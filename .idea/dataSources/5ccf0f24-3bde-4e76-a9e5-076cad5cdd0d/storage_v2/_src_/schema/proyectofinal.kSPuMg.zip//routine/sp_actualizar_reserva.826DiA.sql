create
    definer = root@localhost procedure sp_actualizar_reserva(IN p_Cedula varchar(11), IN p_Nueva_Placa varchar(9),
                                                             IN p_Nueva_FechaEntrega date,
                                                             IN p_Nueva_FechaDevolucion date)
BEGIN
    DECLARE v_IDCliente INT;
    DECLARE v_IDCarro INT;
    DECLARE v_CarroDisponible BOOLEAN;
    DECLARE v_TieneReservaActiva BOOLEAN;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN 
        ROLLBACK;
        RESIGNAL;
    END;
    
    -- Obtener ID del cliente
    SELECT IDCliente INTO v_IDCliente 
    FROM Cliente 
    WHERE Cedula = p_Cedula;
    
    IF v_IDCliente IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Cliente no encontrado';
    END IF;
    
    -- Verificar si tiene reserva activa
    SELECT EXISTS(
        SELECT 1 FROM Reserva 
        WHERE IDCliente = v_IDCliente 
        AND Cancelacion = FALSE
    ) INTO v_TieneReservaActiva;
    
    IF NOT v_TieneReservaActiva THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'El cliente no tiene reservas activas';
    END IF;
    
    -- Obtener ID del nuevo carro
    SELECT IDCarro INTO v_IDCarro 
    FROM Carro 
    WHERE Placa = p_Nueva_Placa;
    
    IF v_IDCarro IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Carro no encontrado';
    END IF;
    
    -- Validar fechas
    IF p_Nueva_FechaEntrega >= p_Nueva_FechaDevolucion THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Fecha de entrega debe ser anterior a devolución';
    END IF;
    
    SELECT NOT EXISTS (
        SELECT 1 FROM Reserva 
        WHERE IDCarro = v_IDCarro 
        AND Cancelacion = FALSE
        AND IDCliente != v_IDCliente
        AND (
            (p_Nueva_FechaEntrega BETWEEN FechaDeEntrega AND FechaDevolucion) OR
            (p_Nueva_FechaDevolucion BETWEEN FechaDeEntrega AND FechaDevolucion) OR
            (FechaDeEntrega BETWEEN p_Nueva_FechaEntrega AND p_Nueva_FechaDevolucion)
        )
    ) INTO v_CarroDisponible;
    
    IF NOT v_CarroDisponible THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Carro no disponible para las fechas seleccionadas';
    END IF;
    
    START TRANSACTION;
    
    UPDATE Reserva
    SET 
        IDCarro = v_IDCarro,
        FechaDeEntrega = p_Nueva_FechaEntrega,
        FechaDevolucion = p_Nueva_FechaDevolucion
    WHERE IDCliente = v_IDCliente
    AND Cancelacion = FALSE;
    
    COMMIT;
END;

