create
    definer = root@localhost procedure sp_borrar_empleado(IN p_Cedula varchar(11))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
    BEGIN
        ROLLBACK;
        RESIGNAL;
    end;

    START TRANSACTION;

    DELETE FROM Empleado
    WHERE cedula = p_cedula;

    COMMIT;
end;

