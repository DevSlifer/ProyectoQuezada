create definer = root@localhost view rentacliente as
select `c`.`Nombre`                                                                                   AS `Nombre`,
       `c`.`Apellido`                                                                                 AS `Apellido`,
       `c`.`Cedula`                                                                                   AS `Cedula`,
       `c`.`telefono`                                                                                 AS `telefono`,
       `ca`.`Marca`                                                                                   AS `Marca`,
       `ca`.`Modelo`                                                                                  AS `Modelo`,
       `ca`.`Placa`                                                                                   AS `Placa`,
       `ca`.`preciopordia`                                                                            AS `PrecioPorDia`,
       `r`.`FechaReservacion`                                                                         AS `FechaReservacion`,
       `r`.`FechaDeEntrega`                                                                           AS `FechaDeEntrega`,
       `r`.`FechaDevolucion`                                                                          AS `FechaDevolucion`,
       ((to_days(`r`.`FechaDevolucion`) - to_days(`r`.`FechaDeEntrega`)) + 1)                         AS `DiasTotal`,
       (((to_days(`r`.`FechaDevolucion`) - to_days(`r`.`FechaDeEntrega`)) + 1) * `ca`.`preciopordia`) AS `MontoEstimado`
from ((`proyectofinal`.`cliente` `c` join `proyectofinal`.`reserva` `r`
       on ((`c`.`IDCliente` = `r`.`IDCliente`))) join `proyectofinal`.`carro` `ca`
      on ((`ca`.`IDCarro` = `r`.`IDCarro`)))
where (`r`.`Cancelacion` = false);

