create definer = root@localhost trigger validar_precio_carro
    before insert
    on carro
    for each row
BEGIN
    IF NEW.PrecioPorDia <= 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'El precio por día debe ser mayor a 0';
    END IF;
END;

