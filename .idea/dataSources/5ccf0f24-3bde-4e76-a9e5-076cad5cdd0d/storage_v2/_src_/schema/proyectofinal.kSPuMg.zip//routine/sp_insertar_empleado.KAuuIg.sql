create
    definer = root@localhost procedure sp_insertar_empleado(IN p_Nombre varchar(20), IN p_Apellido varchar(20),
                                                            IN p_Salario decimal(10, 2), IN p_Cedula varchar(11),
                                                            IN p_telefono varchar(13))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
    BEGIN
        ROLLBACK;
        RESIGNAL;
    end;

    START TRANSACTION;

    INSERT INTO Empleado (Nombre, Apellido, Salario, Cedula, telefono)
    VALUES (p_Nombre, p_Apellido, p_Salario, p_Cedula, p_telefono);

    COMMIT;
end;

