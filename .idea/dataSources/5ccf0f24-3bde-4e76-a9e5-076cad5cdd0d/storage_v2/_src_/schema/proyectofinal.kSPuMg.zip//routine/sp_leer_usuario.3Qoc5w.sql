create
    definer = root@localhost procedure sp_leer_usuario(IN p_correo varchar(50), IN p_contrasena varchar(255))
BEGIN
    SELECT email, contrasena, rol
    FROM usuarios
    WHERE email = p_correo AND contrasena = SHA2(p_contrasena, 256);
END;

