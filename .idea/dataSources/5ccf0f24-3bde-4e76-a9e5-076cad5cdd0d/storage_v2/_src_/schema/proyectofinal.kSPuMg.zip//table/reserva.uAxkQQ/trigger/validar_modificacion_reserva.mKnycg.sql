create definer = root@localhost trigger validar_modificacion_reserva
    before update
    on reserva
    for each row
BEGIN
    IF OLD.Cancelacion = TRUE AND NEW.Cancelacion = FALSE THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'No se puede reactivar una reserva cancelada';
    END IF;
END;

