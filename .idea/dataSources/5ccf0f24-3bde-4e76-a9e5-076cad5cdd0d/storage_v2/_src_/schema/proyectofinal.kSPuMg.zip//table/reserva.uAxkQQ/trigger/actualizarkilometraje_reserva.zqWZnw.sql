create definer = root@localhost trigger actualizarKilometraje_Reserva
    after update
    on reserva
    for each row
BEGIN
    -- Si la reserva cambió a estado finalizado/completado
    IF NEW.Cancelacion = TRUE AND OLD.Cancelacion = FALSE THEN
        -- Actualizar el kilometraje del carro
        UPDATE Carro
        SET Kilometraje = Kilometraje + 150
        WHERE IDCarro = NEW.IDCarro;
    END IF;
END;

