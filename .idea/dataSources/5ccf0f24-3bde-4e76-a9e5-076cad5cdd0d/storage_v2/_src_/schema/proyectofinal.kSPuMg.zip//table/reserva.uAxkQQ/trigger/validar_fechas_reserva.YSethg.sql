create definer = root@localhost trigger validar_fechas_reserva
    before insert
    on reserva
    for each row
BEGIN
    IF NEW.FechaDevolucion <= NEW.FechaDeEntrega THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'La fecha de devolución debe ser posterior a la fecha de entrega';
    END IF;
    
    IF NEW.FechaDeEntrega < CURDATE() THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'No se pueden hacer reservas con fechas pasadas';
    END IF;
END;

