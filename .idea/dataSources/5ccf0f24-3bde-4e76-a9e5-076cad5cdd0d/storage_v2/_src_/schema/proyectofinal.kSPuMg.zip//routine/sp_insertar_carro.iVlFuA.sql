create
    definer = root@localhost procedure sp_insertar_carro(IN p_Marca varchar(20), IN p_Modelo varchar(20), IN p_Anio int,
                                                         IN p_Placa varchar(9), IN p_kilometraje decimal(10, 2),
                                                         IN p_preciopordia decimal(6, 2), IN p_Matricula varchar(50))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
    BEGIN
        ROLLBACK;
        RESIGNAL;
    end;
    START TRANSACTION;
    INSERT INTO Carro (Marca, Modelo, Anio, Placa,kilometraje, Matricula,preciopordia)
    VALUES (p_Marca, p_Modelo, p_Anio,  p_Placa,p_kilometraje,  p_Matricula, p_preciopordia);
    COMMIT;
END;

