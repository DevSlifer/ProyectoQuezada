create definer = root@localhost view facturasgeneradas as
select `c`.`Nombre`            AS `nombre`,
       `c`.`Apellido`          AS `apellido`,
       `c`.`Cedula`            AS `cedula`,
       `f`.`Monto`             AS `monto`,
       `f`.`CargosAdicionales` AS `Cargos_adicionales`,
       `f`.`FechaDePago`       AS `Fecha_de_pago`
from (`proyectofinal`.`cliente` `c` join `proyectofinal`.`factura` `f` on ((`c`.`IDCliente` = `f`.`IDCliente`)));

