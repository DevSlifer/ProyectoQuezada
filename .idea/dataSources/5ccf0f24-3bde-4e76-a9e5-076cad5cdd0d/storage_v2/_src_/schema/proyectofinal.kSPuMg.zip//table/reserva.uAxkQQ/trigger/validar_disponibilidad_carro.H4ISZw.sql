create definer = root@localhost trigger validar_disponibilidad_carro
    before insert
    on reserva
    for each row
BEGIN
    IF EXISTS (
        SELECT 1 FROM Reserva 
        WHERE IDCarro = NEW.IDCarro 
        AND Cancelacion = FALSE
        AND (
            (NEW.FechaDeEntrega BETWEEN FechaDeEntrega AND FechaDevolucion)
            OR (NEW.FechaDevolucion BETWEEN FechaDeEntrega AND FechaDevolucion)
        )
    ) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'El carro no está disponible para las fechas seleccionadas';
    END IF;
END;

