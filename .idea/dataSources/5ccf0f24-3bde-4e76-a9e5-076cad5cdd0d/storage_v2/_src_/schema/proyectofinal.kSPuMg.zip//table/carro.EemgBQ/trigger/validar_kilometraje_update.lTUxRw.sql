create definer = root@localhost trigger validar_kilometraje_update
    before update
    on carro
    for each row
BEGIN
    IF NEW.Kilometraje < OLD.Kilometraje THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'El nuevo kilometraje no puede ser menor al anterior';
    END IF;
END;

