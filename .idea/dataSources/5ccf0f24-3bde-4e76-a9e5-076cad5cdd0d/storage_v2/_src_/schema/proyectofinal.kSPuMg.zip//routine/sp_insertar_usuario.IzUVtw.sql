create
    definer = root@localhost procedure sp_insertar_usuario(IN p_email varchar(100), IN p_contrasena varchar(255),
                                                           IN p_rol enum ('empleado', 'admin'))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    IF p_rol NOT IN ('admin', 'empleado') THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Rol no válido. Los roles permitidos son: admin, empleado';
    END IF;

    START TRANSACTION;

    -- Inserción del usuario
    INSERT INTO usuarios (
        email,
        contrasena,
        rol,
        fecha_creacion
    )
    VALUES (
        p_email,
        SHA2(p_contrasena, 256),
        p_rol,
        NOW()
    );

    COMMIT;
END;

